from flask import Flask, jsonify, render_template
from flask_cors import CORS
from datetime import datetime, timedelta

app = Flask(__name__)
CORS(app)



@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/data')
def get_data():
    start_date = datetime(2025, 12, 1)
    data = []
    for i in range(30):
        date = start_date + timedelta(days=i)
        sales = 100 + i * 10 + (i * 3) % 50
        temp = 20 + (i % 7) * 5 - 10
        data.append({
            'date': date.isoformat(),
            'sales': sales,
            'temperature': temp,
            'category': 'Ventes' if i % 2 == 0 else 'Température'
        })
    return jsonify({'timeseries': data})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
