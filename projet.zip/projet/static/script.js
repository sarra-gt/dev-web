let mainChart, secondaryChart, data = [];

function updateResultCount(count) {
    let counter = document.getElementById('resultCount');
    if (!counter) {
        const filters = document.getElementById('filters');
        counter = document.createElement('div');
        counter.id = 'resultCount';
        counter.style.cssText = 'margin-top: 1rem; padding: 1rem; background: #10b981; color: white; border-radius: 8px; font-weight: bold; text-align: center;';
        filters.appendChild(counter);
    }
    counter.textContent = `${count} résultats affichés`;
}

function initApp() {
    if (typeof Chart === 'undefined') {
        setTimeout(initApp, 100);
        return;
    }
    loadData().then(() => setupEvents());
}

document.addEventListener('DOMContentLoaded', initApp);

async function loadData() {
    try {
        const res = await fetch('/api/data');
        const result = await res.json();
        data = result.timeseries;
        updateCharts(data);
        updateTable(data);
        updateResultCount(data.length);
    } catch (e) {
        console.error('API:', e);
    }
}

function setupEvents() {
    document.getElementById('toggleChart').onclick = () => {
        const charts = document.getElementById('charts');
        charts.style.display = charts.style.display === 'none' ? 'grid' : 'none';
        document.getElementById('toggleChart').textContent = charts.style.display === 'none' ? 'Afficher' : 'Masquer';
    };

    document.getElementById('filterForm').onsubmit = (e) => {
        e.preventDefault();
        const date = document.getElementById('dateFilter').value;
        const cat = document.getElementById('categoryFilter').value;
        
        const filtered = data.filter(item => {
            const itemDate = item.date.split('T')[0];
            return (!date || itemDate === date) && (cat === 'all' || item.category === cat);
        });
        
        updateCharts(filtered);
        updateTable(filtered);
        updateResultCount(filtered.length);
    };
}

function updateCharts(dataset) {
    updateMainChart(dataset);
    updateSecondaryChart(dataset.slice(0, 10));
}

function updateMainChart(dataset) {
    const canvas = document.getElementById('mainChart');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (mainChart) mainChart.destroy();
    
    mainChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: dataset.map(d => new Date(d.date).toLocaleDateString('fr-FR')),
            datasets: [
                { 
                    label: 'Ventes', 
                    data: dataset.map(d => d.sales), 
                    borderColor: '#10b981', 
                    backgroundColor: 'rgba(16,185,129,0.2)', 
                    tension: 0.4, 
                    fill: true
                },
                { 
                    label: 'Température', 
                    data: dataset.map(d => d.temperature), 
                    borderColor: '#ef4444', 
                    backgroundColor: 'rgba(239,68,68,0.2)', 
                    tension: 0.4, 
                    fill: true, 
                    yAxisID: 'y1'
                }
            ]
        },
        options: { 
            responsive: true, 
            maintainAspectRatio: false, 
            scales: { 
                y: { position: 'left' },
                y1: { position: 'right', grid: { drawOnChartArea: false } }
            },
            plugins: {
                legend: { display: true }
            }
        }
    });
}

function updateSecondaryChart(dataset) {
    const canvas = document.getElementById('secondaryChart');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (secondaryChart) secondaryChart.destroy();
    
    secondaryChart = new Chart(ctx, {
        type: 'bar',
        data: { 
            labels: dataset.map(d => new Date(d.date).toLocaleDateString('fr-FR')), 
            datasets: [{ 
                label: 'Ventes', 
                data: dataset.map(d => d.sales), 
                backgroundColor: '#3b82f6' 
            }] 
        },
        options: { responsive: true, maintainAspectRatio: false }
    });
}

function updateTable(dataset) {
    const table = document.getElementById('dataTableBody');
    if (!table) return;
    
    table.innerHTML = `
        <thead style="background: #f3f4f6;">
            <tr><th style="padding: 1rem;">Date</th><th style="padding: 1rem;">Ventes</th><th style="padding: 1rem;">Temp</th><th style="padding: 1rem;">Catégorie</th></tr>
        </thead>
        <tbody>
            ${dataset.map(d => `
                <tr style="border-bottom: 1px solid #e5e7eb;">
                    <td style="padding: 1rem;">${new Date(d.date).toLocaleDateString()}</td>
                    <td style="padding: 1rem; font-weight: bold;">${d.sales}</td>
                    <td style="padding: 1rem;">${d.temperature}°C</td>
                    <td style="padding: 1rem; ${d.category === 'Ventes' ? 'color: #10b981;' : 'color: #ef4444;' }">${d.category}</td>
                </tr>
            `).join('')}
        </tbody>
    `;
}
